package com.OnlineExam.deloitte.model;

public class Statistic {
	
	private String statCategory;
	private String statDateTime;
	private String stateName;
	private String statEmail;
	private int statScore;

}
