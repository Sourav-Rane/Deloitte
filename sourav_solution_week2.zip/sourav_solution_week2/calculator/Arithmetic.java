package calculator;

public abstract class Arithmetic {
	abstract int calculate(int num1 ,  int num2);
	abstract int read();
	abstract void display(int result);
}
