package com.pms.deloitte.client;

public class Client {

	public static void main(String[] args) {

		LaunchProductApplication.startCustomerApp();
	}
}
