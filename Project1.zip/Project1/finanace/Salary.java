package finanace;

public class Salary {
	public int calSal(int basic , int pf) {
		return basic + pf;
	}
}
