
public class Deloitte {

		public void sayDeloitte() {
			System.out.println("Hi deloitte !");
		}
}
