
public class Apple {
	
	public void sayApple() {
		System.out.println("This is apple ! ");
	}
}
